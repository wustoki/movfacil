<?php
header("Location:painel/index.php");
?>