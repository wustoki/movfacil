<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sucesso</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 20px;
            text-align: center;
            background-color: #f4f4f4;
        }

        h1 {
            color: #4CAF50;
        }

        p {
            color: #333;
        }
    </style>
</head>
<body>
    <h1>Pagamento realizado com sucesso!</h1>
    <p>Volte ao aplicativo e aguarde o saldo ser atualizado.</p>
</body>
</html>
