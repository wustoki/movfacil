<?php
// Define que a origem do acesso pode ser de qualquer lugar
header('access-control-allow-origin: *');

// Inclui as classes necessárias
include_once "../classes/clientes.php";
include_once "../classes/cpf.php";
include_once "../classes/send_mail.php";
include "../classes/alertas.php";
// Adicione a inclusão do arquivo de configuração do banco de dados
include "../bd/config.php"; 

// Cria instâncias das classes
$clientes = new Clientes();
$cp = new cpf();
$mail = new enviaEmail();
$a = new alertas();

// Recebe os dados do formulário enviados via POST
$cidade_id       = $_POST['cidade_id'];
$nome            = $_POST['nome'];
$numero_telefone = $_POST['telefone'];
$senha           = $_POST['senha'];
$latitude        = $_POST['latitude'];
$longitude       = $_POST['longitude'];
$cpf             = $_POST['cpf'];
$email           = $_POST['email'];

//---------------------------------------------------------
// (REMOVIDO O reCAPTCHA) – daqui em diante segue o fluxo original
//---------------------------------------------------------

// Define o salt para o hash da senha
$salt  = "anjdsn5s141d5";
$senha = md5($senha.$salt);

// Limpa e formata o número de telefone
$numero_telefone = str_replace(["(", ")", "-", " "], "", $numero_telefone);

// Verifica se o telefone já existe
$verifica = $clientes->verifica_se_existe($numero_telefone);
if ($verifica) {
    echo json_encode(["status" => "Telefone já cadastrado"]);
    exit;
}

// Valida o CPF
if (!$cp->validar($cpf)) {
    echo json_encode(["status" => "CPF inválido"]);
    exit;
}

// Cadastra o cliente no banco de dados
// ⚠️ IMPORTANTE: a função cadastra() precisa retornar o ID do cliente inserido
$id_novo_cliente = $clientes->cadastra($cidade_id, $nome, $numero_telefone, $senha, $latitude, $longitude, $cpf, $email);

if ($id_novo_cliente) {
    // Inicia a automação de forma segura
    try {
        $pdo = new PDO($config['dsn'], $config['user'], $config['pass'], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);

        // Insira o evento na tabela integracao_outbox
        $novo_payload = [
            'id_tabela' => $id_novo_cliente
        ];

        $q = $pdo->prepare("
            INSERT INTO integracao_outbox (event_type, payload)
            VALUES ('cliente_cadastrado', ?)
        ");
        $q->execute([json_encode($novo_payload)]);

    } catch (Throwable $e) {
        error_log("Erro automação cliente_cadastrado: " . $e->getMessage());
    }

    // Envia o e-mail de confirmação de cadastro
    $mail->sendEmail(
        $email,
        "Cadastro realizado com sucesso",
        "Obrigado por se cadastrar no app Wustoki. Agora você já pode chamar o seu motorista e contar com a gente para te levar aonde você quiser. Aproveite!"
    );
    
    // Insere o alerta para o novo usuário
    $a->insereAlerta($cidade_id, "Novo usuário cadastrado: $nome", "listar_clientes.php");
    
    echo json_encode(["status" => "sucesso"]);
} else {
    echo json_encode(["status" => "erro"]);
}
?>