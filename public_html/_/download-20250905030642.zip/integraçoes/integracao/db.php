<?php
return [
  'dsn' => 'mysql:host=localhost;dbname=mobilidade;charset=utf8mb4',
  'user' => 'mobilidade',
  'pass' => 'luna2017',

  'webhook_url' => 'https://automacaowebhook.wustoki.com.br/webhook/integracao-app',

  'token' => '@Luna2017@Filho2019'
];
