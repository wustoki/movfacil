<?php
$config = require __DIR__ . '/db.php';

if (!isset($_GET['token']) || $_GET['token'] !== $config['token']) {
    http_response_code(403);
    exit('forbidden');
}

try {
    $pdo = new PDO($config['dsn'], $config['user'], $config['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);

    $stmt = $pdo->query("
        SELECT id, event_type, payload
        FROM integracao_outbox
        WHERE delivered_at IS NULL AND tries < 5
        ORDER BY id ASC
        LIMIT 50
    ");
    $events = $stmt->fetchAll();

    $sent = 0; 
    $failed = 0;

    foreach ($events as $ev) {
        $payload = json_decode($ev['payload'], true) ?: [];

        // Evento motorista_aprovado
        if ($ev['event_type'] === 'motorista_aprovado' && !empty($payload['id_tabela'])) {
            $q = $pdo->prepare("
                SELECT id, nome, telefone, email, cpf, cidade_id, veiculo, placa, ids_categorias, ativo
                FROM motoristas 
                WHERE id = ?
            ");
            $q->execute([$payload['id_tabela']]);
            if ($m = $q->fetch()) {
                $m['status'] = $m['ativo'] ? 'aprovado' : 'pendente';
                $m['email']  = $m['email'] ?? ''; // garante sempre existir
                $payload['motorista'] = $m;
            }
        } 
        // Evento motorista_cadastrado
        elseif ($ev['event_type'] === 'motorista_cadastrado' && !empty($payload['id_tabela'])) {
            $q = $pdo->prepare("
                SELECT id, nome, telefone, email, cpf, veiculo, placa, cidade_id, 
                       img_cnh, img_documento, img_lateral, img_frente, img_selfie, aprovado
                FROM motorista_docs 
                WHERE id_tabela = ?
            ");
            $q->execute([$payload['id_tabela']]);
            if ($m = $q->fetch()) {
                $m['status'] = $m['aprovado'] ? 'aprovado' : 'pendente';
                $m['email']  = $m['email'] ?? ''; // garante sempre existir
                $payload['motorista'] = $m; 
            }
        }

        // Envio para o webhook do n8n (Mautic)
        $ch = curl_init($config['webhook_url']);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => json_encode([
                'event'   => $ev['event_type'],
                'data'    => $payload,
                'sent_at' => date('c')
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            CURLOPT_TIMEOUT => 15
        ]);
        $resp = curl_exec($ch);
        $err  = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($err || $code < 200 || $code >= 300) {
            $upd = $pdo->prepare("
                UPDATE integracao_outbox
                SET tries = tries + 1, last_error = ?, updated_at = NOW()
                WHERE id = ?
            ");
            $upd->execute([substr("HTTP $code | $err | $resp", 0, 1000), $ev['id']]);
            $failed++;
        } else {
            $upd = $pdo->prepare("
                UPDATE integracao_outbox
                SET delivered_at = NOW(), updated_at = NOW()
                WHERE id = ?
            ");
            $upd->execute([$ev['id']]);
            $sent++;
        }
    }

    header('Content-Type: application/json');
    echo json_encode(['ok' => true, 'sent' => $sent, 'failed' => $failed], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
    http_response_code(500);
    echo "erro: " . $e->getMessage();
}