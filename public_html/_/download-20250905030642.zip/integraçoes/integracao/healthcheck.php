<?php
echo "OK - " . date('c');
