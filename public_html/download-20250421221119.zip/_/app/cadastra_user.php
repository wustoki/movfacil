<?php 
header('access-control-allow-origin: *');
include_once "../classes/clientes.php";
include_once "../classes/cpf.php";
include_once "../classes/send_mail.php";
include "../classes/alertas.php";
$clientes = new Clientes();
$cp = new cpf();
$mail = new enviaEmail();
$a = new alertas();

$cidade_id = $_POST['cidade_id'];
$nome = $_POST['nome'];
$numero_telefone = $_POST['telefone'];
$senha = $_POST['senha']; 
$cidade_id = $_POST['cidade_id'];
$latitude = $_POST['latitude'];
$longitude = $_POST['longitude'];
$cpf = $_POST['cpf'];
$email = $_POST['email'];

$salt = "anjdsn5s141d5";
$senha = md5($senha.$salt);


$numero_telefone = str_replace("(", "", $numero_telefone);
$numero_telefone = str_replace(")", "", $numero_telefone);
$numero_telefone = str_replace("-", "", $numero_telefone);
$numero_telefone = str_replace(" ", "", $numero_telefone);

//verifica se o telefone já existe
$verifica = $clientes->verifica_se_existe($numero_telefone);
if($verifica){
    echo json_encode(array("status" => "Telefone já cadastrado"));
    exit;
}

//valida o cpf
if(!$cp->validar($cpf)){
    echo json_encode(array("status" => "CPF inválido" . $cpf));
    exit;
}

//cadastra o cliente
$cadastra = $clientes->cadastra($cidade_id, $nome, $numero_telefone, $senha, $latitude, $longitude, $cpf, $email);
if($cadastra){
    echo $mail->sendEmail($email, "Cadastro realizado com sucesso",
    "Obrigado por se cadastrar no app Wustoki. Agora você já pode chamar o seu motorista e contar com a gente para te levar aonde você quiser. Aproveite!");
    $a ->insereAlerta($cidade_id, "Novo usuário cadastrado: $nome", "listar_clientes.php");
    echo json_encode(array("status" => "sucesso"));
}else{
    echo json_encode(array("status" => "erro"));
}
?>