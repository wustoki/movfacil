<?php
header("Access-Control-Allow-Origin: *");
include '../classes/corridas.php';
include '../classes/configuracoes_pagamento.php';
include '../classes/status_historico.php';

class get_pegamento
{
    public $dados;

    public function get()
    {

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.pagmp.com/api/verifica_pagamento.php",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $this->dados,

        ));

        $response = curl_exec($curl);
        // echo $response;
        curl_close($curl);
        return $response;
    }
}


$p = new corridas();
$cp = new configuracoes_pagamento();
$gp = new get_pegamento();
$sh = new status_historico();

$alterou = false;

if(isset($_POST['cidade_id'])){
    $cidade_id = $_POST['cidade_id'];
} else {
    $cidade_id = $_SESSION['cidade_id'];
}
$token = $cp->read_configuracoes_pagamento($cidade_id)['token'];
$pedidos_ativos = $p->get_all_corridas_cidade($cidade_id);
foreach ($pedidos_ativos as $pedido) {
    if ($pedido['pagamento'] == "Pagamento Online")
        if ($pedido['status_pagamento'] == "PENDING") {
            if ($pedido['ref_pagamento'] != "") {
                $gp->dados = array(
                    "token" => $token,
                    "ref" => $pedido['ref_pagamento']
                );
                $resposta = $gp->get();
                $resposta = json_decode($resposta, true);
                $status_pagamento = $resposta['status'];
                if ($status_pagamento == "Aprovado" || $status_pagamento == "Autorizado") {
                    $status_string = "Pagamento Online Recebido";
                    $p->update_status_pagamento($pedido['id'], $status_pagamento);
                    $sh->salva_status($pedido['id'], $status_string);
                    $alterou = true;
                }
            }
        }
}
if ($alterou) {
    echo "1";
} else {
    echo "0";
}
