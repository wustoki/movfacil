<?
include("seguranca.php");
$mensagem = $_POST['mensagem'];
$titulo = $_POST['titulo'];
$destino = $_POST['destino'];


function sendMessage($app_id, $msg, $title, $key_one_signal){
    $content = array(
        "en" => $msg
        );
    $headings = array(
        "en" => $title
    );

    $fields = array(
        'app_id' => $app_id,
        'included_segments' => array('All'),
        'contents' => $content,
        "headings" => $headings
    );

    $fields = json_encode($fields);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
                                               'Authorization: Basic '.$key_one_signal.''));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);    

    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}

$player = "All";
$key_one_signal_motoristas = "ODI2MGUyZTAtYjE2NC00ZGQzLWEzZDItNmJiZTYzOTQyNDhj";
$app_id_motoristas = "df3f3d0f-0318-4993-bbde-b1d363b49bf3";
$key_one_signal_usuarios = "Y2EyZjkzYmQtMWZjMy00ZjExLTgxYmUtYjk4ZDU1MmI1NWMw";
$app_id_usuarios = "6f8db040-fda6-4d3d-bf27-26782e2978d2";
if($destino == 1){
    $response = sendMessage($app_id_motoristas, $mensagem, $titulo, $key_one_signal_motoristas);
}else if($destino == 2){
    $response = sendMessage($app_id_usuarios, $mensagem, $titulo, $key_one_signal_usuarios);
}else if($destino == 3){
    $response = sendMessage($app_id_motoristas, $mensagem, $titulo, $key_one_signal_motoristas);
    $response = sendMessage($app_id_usuarios, $mensagem, $titulo, $key_one_signal_usuarios);
}
//echo $response;
echo "<script>alert('Push enviado com sucesso!');</script>";
echo "<script>location.href='novo_push.php';</script>";

?>