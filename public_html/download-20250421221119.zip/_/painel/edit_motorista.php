<?php
include("seguranca.php");
include("nivel_acesso.php");
include "../classes/motoristas.php";
include "../classes/upload.php";
include "../classes/transacoes_motoristas.php";
include "../classes/franqueados.php";
$m = new motoristas();
$t = new transacoes_motoristas($cidade_id);
$f = new franqueados();

//entrada de formulário
$id_motorista=$_GET['id'];
$dados = $m->get_motorista($id_motorista);
$saldo_antigo = str_replace(",", ".", $dados['saldo']);


$franqueado_id = $_SESSION['id_usuario'];
$franqueado = $f->get_usuario_id($franqueado_id);
$limite_credito_motorista = $franqueado['limite_credito_motorista'];

$nome = $_POST['nome'];
$cpf= $_POST['cpf'];
$veiculo= $_POST['veiculo'];
$placa = $_POST['placa'];
$telefone= $_POST['telefone'];
$senha= $_POST['senha'];
$taxa = $_POST['taxa'];
$ids_categorias = $_POST['ids_categorias'];
$email = $_POST['email'];
$validade_cnh = $_POST['validade_cnh'];
$validade_doc_veiculo = $_POST['validade_doc_veiculo'];
$taxa_semanal = $_POST['taxa_semanal'];


$saldo = $_POST['saldo'];
$saldo = str_replace(",", ".", $saldo);

$limite_credito = $_POST['limite_credito'];
if($limite_credito > $limite_credito_motorista){
    echo "<script>alert('Limite de crédito não pode ser maior que o limite de crédito do franqueado que é de R$ $limite_credito_motorista');</script>";
    echo "<script>window.location.href='editar_motorista.php?id=$id_motorista';</script>";
    exit;
}else{
    $m->updateLimiteCredito($id_motorista, $limite_credito);
}

if($saldo_antigo < $saldo){
$valor_difereca = $saldo - $saldo_antigo;
$valor_difereca = number_format($valor_difereca, 2, ',', '.');
$t ->insereTransacao($id_motorista, "", $valor_difereca, "CREDITO PLATAFORMA", "CONCLUIDO");
}else if($saldo_antigo > $saldo){
$valor_difereca = $saldo_antigo - $saldo;
$valor_difereca = number_format($valor_difereca, 2, ',', '.');
$t ->insereTransacao($id_motorista, "", $valor_difereca, "DEBITO PLATAFORMA", "CONCLUIDO");
}

//verifica se possui nova imagem
//parametros para imagem
$pasta='../admin/uploads/';
$img=$_FILES['img'];
if($img['name'] != ""){
    $upload = new Upload($img, 800, 800, $pasta);
    $nome_img = $upload->salvar();
}else{
	$nome_img = $dados['img'];
}

//atualiza dados
$m->edit_motorista($id_motorista, $nome, $cpf, $nome_img, $veiculo, $placa, $telefone, $senha, $taxa, $saldo, $ids_categorias);
$m->updateEmail($id_motorista, $email);
$m->updateValidade_cnh($id_motorista, $validade_cnh);
$m->updateValidadeDocVeiculo($id_motorista, $validade_doc_veiculo);
$m->setTaxaSemanal($id_motorista, $taxa_semanal);
echo "<script>alert('Dados atualizados com sucesso!');</script>";

$origem = $_POST['origem'];
if($origem == "lista_motoristas_temp"){
    echo "<script>window.location.href='lista_motoristas_temp.php';</script>";
}else{
echo "<script>window.location.href='listar_motoristas.php';</script>";
} 


?>