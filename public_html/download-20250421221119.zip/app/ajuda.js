//feito com bootblocks.com.br
  if (true) {
  }
  $("body").css("height", "100%");
  $("html").css("height", "100%");

        $(document).ready(function(){
            $("#loading-page-bb").css("opacity", "1");
        });