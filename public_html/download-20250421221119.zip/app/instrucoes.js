// Descreva esta função...
function iniciar_download() {
  window.location.href = 'https://wustoki.top/apk/motorista_wustoki.apk';
}


//feito com bootblocks.com.br
  document.getElementById('btn_download').style.height = '100' + "px";
  document.getElementById('btn_download').style.width = '100' + "%";
  document.getElementById('btn_download').style.height = "auto";

        $(document).ready(function(){
            $("#loading-page-bb").css("opacity", "1");
        });